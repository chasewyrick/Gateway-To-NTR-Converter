#ifndef CHEATS_H
#define CHEATS_H

#include "plugin.h"

void	Test(void);

#endif
